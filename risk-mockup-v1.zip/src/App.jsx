
import React, { useState } from 'react'

function Status({ s }){
  const map = { Draft:'gray', Submitted:'blue', Approved:'green', 'Needs changes':'amber', Overdue:'red' }
  return <span className={`badge ${map[s]||'gray'}`}>{s}</span>
}

function KPI({title, value, sub}){
  return (<div className="card kpi">
    <div className="title">{title}</div>
    <div className="value">{value}</div>
    {sub && <div className="sub">{sub}</div>}
  </div>)
}

function Toolbar({children}){ return <div className="toolbar">{children}</div> }

function Table({columns, rows}){
  return (<div className="card"><div className="body" style={{padding:0}}>
    <div style={{overflow:auto}}>
      <table className="table">
        <thead><tr>{columns.map(c=><th key={c}>{c}</th>)}</tr></thead>
        <tbody>
          {rows.map((r,i)=>(<tr key={i}>
            {columns.map(c=><td key={c}>{r[c]}</td>)}
          </tr>))}
        </tbody>
      </table>
    </div>
  </div></div>)
}

export default function App(){
  const [page, setPage] = useState('home')
  const [approvalMode, setApprovalMode] = useState('diff')
  const Nav = ({id, label}) =>
    <button className={` ${page===id?'active':''}`} onClick={()=>setPage(id)}>{label}</button>

  return (<>
    <div className="topbar">
      <div className="topbar-inner">
        <div className="brand">Risk System</div>
        <div className="nav">
          <Nav id="home" label="Home" />
          <Nav id="risks" label="Risks" />
          <Nav id="updates" label="Quarterly Updates" />
          <Nav id="approvals" label="Approvals" />
          <Nav id="reports" label="Reports" />
          <Nav id="dashboard" label="Dashboard" />
          <Nav id="admin" label="Admin" />
        </div>
        <div className="iconbar">
          <button className="iconbtn" title="Notifications">🔔</button>
          <button className="iconbtn" title="User">👤</button>
        </div>
      </div>
    </div>

    <div className="container">
      {page==='home' && (<>
        <div className="section-title">Welcome back, Alice</div>
        <div className="row">
          <div className="col col-4" style={{gridColumn:'span 4'}}><KPI title="My drafts" value="3" sub="Continue your work" /></div>
          <div className="col col-4" style={{gridColumn:'span 4'}}><KPI title="Waiting for my approval" value="5" sub="Manager queue" /></div>
          <div className="col col-4" style={{gridColumn:'span 4'}}><KPI title="Due soon" value="Q2 ends: 15 Jul" /></div>
        </div>
        <Toolbar>
          <button className="btn primary">＋ New Risk</button>
          <button className="btn">📅 New Quarterly Update</button>
          <button className="btn">📄 Bulk Import (.xlsx)</button>
        </Toolbar>
        <div className="section-title">Recent activity</div>
        <div className="card"><div className="body">
          • You submitted <b>Ops Risk - Warehouse</b> (Q2)<br/>
          • Manager requested changes: <b>Supply Risk - Delay</b>
        </div></div>
      </>)}

      {page==='risks' && (<>
        <div className="section-title">Risks</div>
        <Toolbar>
          <select className="select"><option>BU: All</option></select>
          <select className="select"><option>Owner: All</option></select>
          <select className="select"><option>Category: All</option></select>
          <select className="select"><option>Status: All</option></select>
          <div className="search"><input className="input" placeholder="Search..." /></div>
          <div style={{flex:1}} />
          <button className="btn primary">＋ New Risk</button>
        </Toolbar>
        <Table columns={['Risk Title','BU','Owner','Category','Inherent','Residual','Target','Status']}
               rows={[
                {'Risk Title':'Supplier delay','BU':'Retail','Owner':'Alice','Category':'Operational','Inherent':9,'Residual':6,'Target':4,'Status':<Status s="Approved" />},
                {'Risk Title':'Cyber breach','BU':'IT','Owner':'Bob','Category':'Cyber','Inherent':12,'Residual':8,'Target':5,'Status':<Status s="Submitted" />},
               ]}
        />
      </>)}

      {page==='updates' && (<>
        <div className="section-title">Quarterly Updates</div>
        <Toolbar>
          <select className="select"><option>Period: 2025Q2</option></select>
          <select className="select"><option>BU: All</option></select>
          <select className="select"><option>Owner: All</option></select>
          <select className="select"><option>Status: All</option></select>
          <div style={{flex:1}} />
          <button className="btn">📅 New Quarterly Update</button>
        </Toolbar>
        <Table columns={['Risk Title','BU','Owner','Period','Status','Last Updated']}
               rows={[
                {'Risk Title':'Supplier delay','BU':'Retail','Owner':'Alice','Period':'2025Q2','Status':<Status s="Submitted" />,'Last Updated':'03 Jul 2025 14:10'},
                {'Risk Title':'Cyber breach','BU':'IT','Owner':'Bob','Period':'2025Q2','Status':<Status s="Draft" />,'Last Updated':'02 Jul 2025 09:20'},
               ]}
        />
      </>)}

      {page==='approvals' && (<>
        <div className="section-title">Approvals</div>
        <Toolbar>
          <select className="select"><option>Period: 2025Q2</option></select>
          <select className="select"><option>BU: All</option></select>
          <label className="toggle"><input type="checkbox" checked={approvalMode==='side'} onChange={e=>setApprovalMode(e.target.checked?'side':'diff')} /> Side-by-Side</label>
        </Toolbar>

        <div className="card"><div className="body">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div><b>Supplier delay</b> <span className="small">(Retail)</span><br/><span className="small">Owner: Alice · Period: 2025Q2</span></div>
            <Status s="Submitted" />
          </div>
          <hr className="sep" />
          {approvalMode==='diff' ? (
            <div>
              <div className="small" style={{marginBottom:6}}>Changes since last approval:</div>
              <div className="card"><div className="body" style={{background:'#fff7ed'}}>Residual Score: <b>7 → 6</b> <span className="badge amber">-1</span></div></div>
            </div>
          ) : (
            <div className="grid grid-2" style={{marginTop:6}}>
              <div className="card"><div className="body"><div className="small">OLD (Approved Q1)</div>Residual: 7<br/>Controls: Extra vendor added</div></div>
              <div className="card"><div className="body"><div className="small">NEW (Submitted Q2)</div><div style={{background:'#ecfdf5',padding:6,borderRadius:8}}>Residual: <b>6</b></div>Controls: same</div></div>
            </div>
          )}
          <hr className="sep" />
          <div style={{display:'flex', gap:8}}>
            <button className="btn" style={{borderColor:'var(--danger)', color:'var(--danger)'}}>✖ Request changes</button>
            <button className="btn primary">✔ Approve</button>
          </div>
        </div></div>
      </>)}

      {page==='reports' && (<>
        <div className="section-title">Reports</div>
        <Toolbar>
          <select className="select"><option>Period: 2025Q2</option></select>
          <select className="select"><option>BU: All</option></select>
          <select className="select"><option>Owner: All</option></select>
          <select className="select"><option>Category: All</option></select>
          <select className="select"><option>Status: All</option></select>
          <div style={{flex:1}} />
          <button className="btn">⬇ Export CSV</button>
          <button className="btn">⬇ Export XLSX</button>
          <button className="btn">⬇ PDF Summary</button>\n        </Toolbar>\n        <Table columns={['Risk Title','BU','Owner','Period','Status','Last Updated']}\n               rows={[\n                {'Risk Title':'Supplier delay','BU':'Retail','Owner':'Alice','Period':'2025Q2','Status':<Status s=\"Approved\" />,'Last Updated':'03 Jul 2025 14:10'},\n                {'Risk Title':'Cyber breach','BU':'IT','Owner':'Bob','Period':'2025Q2','Status':<Status s=\"Submitted\" />,'Last Updated':'02 Jul 2025 09:20'},\n               ]}\n        />\n        <div className=\"small\" style={{marginTop:8}}>All exports are audit-logged.</div>\n      </>)}\n\n      {page==='dashboard' && (<>\n        <div className=\"section-title\">Dashboard</div>\n        <Toolbar>\n          <select className=\"select\"><option>Period: 2025Q2</option></select>\n          <select className=\"select\"><option>BU: All</option></select>\n        </Toolbar>\n        <div className=\"grid grid-2\">\n          <div className=\"card\"><div className=\"body\"><div className=\"title\">Submission Progress</div><div className=\"value\">75%</div><div className=\"sub\">45 of 60 submitted</div></div></div>\n          <div className=\"placeholder\">(Top 10 Risks by Residual – chart)</div>\n          <div className=\"placeholder\">(Residual Score Trend – chart)</div>\n          <div className=\"placeholder\">(Risks by Category – chart)</div>\n          <div className=\"card\"><div className=\"body\"><div className=\"title\">Incidents This Quarter</div>\n            <div className=\"grid grid-3\">\n              <div className=\"card\"><div className=\"body\"><div className=\"small\">Retail</div><div className=\"value\">1</div></div></div>\n              <div className=\"card\"><div className=\"body\"><div className=\"small\">IT</div><div className=\"value\">2</div></div></div>\n              <div className=\"card\"><div className=\"body\"><div className=\"small\">Logistics</div><div className=\"value\">0</div></div></div>\n            </div>\n          </div></div>\n      </>)}\n\n      {page==='admin' && (<>\n        <div className=\"section-title\">Admin</div>\n        <div className=\"row\">\n          <div className=\"card\" style={{gridColumn:'span 12'}}><div className=\"body\">\n            <b>Tabs:</b> Form Builder · Dashboard Builder · Users & Roles · Reminders · Settings · Audit Log\n          </div></div>\n        </div>\n        <div className=\"section-title\">Form Builder (preview)</div>\n        <div className=\"row\">\n          <div className=\"card\" style={{gridColumn:'span 4'}}><div className=\"body\">\n            <div className=\"title\">Field Palette</div>\n            <div className=\"grid\">\n              {['Short text','Long text','Number','Dropdown','Score','Likelihood','Impact','Attachment','Computed (fx)','Checkbox (required)'].map(x=>\n                <button className=\"btn\" key={x} style={{justifyContent:'flex-start'}}>{x}</button>\n              )}\n            </div>\n          </div></div>\n          <div className=\"card\" style={{gridColumn:'span 8'}}><div className=\"body\">\n            <div className=\"title\">Form Canvas</div>\n            <div className=\"grid grid-2\">\n              <div className=\"field\"><label>Risk Title *</label><input className=\"input\" placeholder=\"e.g., Supplier delay\"/></div>\n              <div className=\"field\"><label>Business Unit *</label><select className=\"select\"><option>Choose BU</option><option>Retail</option><option>IT</option></select></div>\n              <div className=\"field\"><label>Owner *</label><input className=\"input\" placeholder=\"e.g., Alice\"/></div>\n              <div className=\"field\"><label>Category</label><select className=\"select\"><option>Operational</option></select></div>\n              <div className=\"field\"><label>Likelihood (1-5)</label><input className=\"input\" type=\"number\" min=\"1\" max=\"5\"/></div>\n              <div className=\"field\"><label>Impact (1-5)</label><input className=\"input\" type=\"number\" min=\"1\" max=\"5\"/></div>\n              <div className=\"field\" style={{gridColumn:'span 2'}}><label>Risk Score (computed)</label><input className=\"input\" value=\"= Likelihood × Impact\" readOnly/></div>\n              <div className=\"field\" style={{gridColumn:'span 2'}}><label>Attachments (PDF/XLSX/PNG/JPG ≤ 10MB)</label><input className=\"input\" type=\"file\"/></div>\n              <div className=\"field\" style={{gridColumn:'span 2'}}><label>Comments (per field)</label><textarea placeholder=\"Threaded comments enabled\"></textarea></div>\n            </div>\n          </div></div>\n        </div>\n      </>)}\n\n    </div>\n  </>)}\n